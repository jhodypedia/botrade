require('dotenv').config();
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { createRootConnection, initPool, getPool } = require('./connection');
async function bootstrapDatabase() {
  const dbName = process.env.MYSQL_DATABASE || 'trade_bot_latest';
  const root = await createRootConnection();
  await root.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
  await root.end();
  await initPool();
  const pool = getPool();
  const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  const statements = schema.split(/;\s*\n/).map(v => v.trim()).filter(Boolean);
  for (const statement of statements) await pool.query(statement);
  await seed();
}
async function seed() {
  const pool = getPool();
  const passwordHash = await bcrypt.hash('admin12345', 10);
  await pool.query(`INSERT IGNORE INTO users (id, full_name, email, phone, whatsapp_number, password_hash, role, status) VALUES (1,'Super Admin','admin@tradebot.local','628111111111','628111111111',?,'SUPER_ADMIN','ACTIVE')`, [passwordHash]);
  await pool.query(`INSERT IGNORE INTO subscription_plans (id, plan_code, name, description, price_monthly, access_scope, is_active) VALUES (1,'ALL_BOT_MONTHLY','All Bot Monthly','Akses penuh untuk semua bot aktif dan dashboard user.',?,'ALL_BOTS',1)`, [Number(process.env.BASE_SUBSCRIPTION_PRICE || 25000)]);
  await pool.query(`INSERT IGNORE INTO bot_profiles (id, code, name, category, description, supported_triggers, supported_timeframes, is_active) VALUES (1,'QWEN_SCALP','Qwen Scalp Analyst','MULTI','Bot membaca screenshot chart dan memberikan setup scalping forex / crypto secara singkat.','.forex,.crypto','1m,3m,5m,15m',1)`);
  await pool.query(`INSERT IGNORE INTO bot_sessions (id, session_name, connection_status, pairing_code, qr_text, qr_data_url, last_error) VALUES (1,'default','IDLE','','','','No session started')`);
  await pool.query(`INSERT IGNORE INTO system_settings (setting_key, setting_value) VALUES ('landing_headline','Bot analis trading berbasis WhatsApp untuk membaca screenshot chart dan membantu trader mengambil keputusan lebih cepat.'),('landing_subheadline','Platform ini menggabungkan AI chart analysis, member subscription, kontrol akses nomor WhatsApp, bot session monitor, dan panel admin realtime dalam satu sistem.')`);
}
module.exports = { bootstrapDatabase };
