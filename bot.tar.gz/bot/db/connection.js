const mysql = require('mysql2/promise');
let pool;
async function createRootConnection() {
  return mysql.createConnection({ host: process.env.MYSQL_HOST || '127.0.0.1', port: Number(process.env.MYSQL_PORT || 3306), user: process.env.MYSQL_USER || 'root', password: process.env.MYSQL_PASSWORD || '' });
}
async function initPool() {
  if (pool) return pool;
  pool = mysql.createPool({ host: process.env.MYSQL_HOST || '127.0.0.1', port: Number(process.env.MYSQL_PORT || 3306), user: process.env.MYSQL_USER || 'root', password: process.env.MYSQL_PASSWORD || '', database: process.env.MYSQL_DATABASE || 'trade_bot_latest', waitForConnections: true, connectionLimit: 12 });
  return pool;
}
function getPool() { if (!pool) throw new Error('Pool belum diinisialisasi'); return pool; }
module.exports = { createRootConnection, initPool, getPool };
