# bot

Project final terintegrasi: backend + frontend + WhatsApp bot.

## Basis Baileys
Project ini memakai package `baileys` versi terbaru yang diinstall dari npm registry, sesuai dokumentasi Baileys yang menunjukkan instalasi dengan `npm install baileys` dan menyarankan QR dikirim ke frontend untuk di-render di production.

## Run
1. Copy `.env.example` menjadi `.env`
2. Isi MySQL dan kredensial Qwen
3. `npm install`
4. `npm start`

Perintah `npm start` menjalankan web dan bot sekaligus.

## Login admin seed
- Email: admin@tradebot.local
- Password: admin12345

## Pairing frontend admin
- Jika `PAIRING_PHONE_NUMBER` diisi pada `.env`, bot akan mencoba meminta pairing code dan menampilkannya di admin dashboard.
- Jika tidak, bot tetap mengirim QR ke database lalu QR dirender di frontend admin.

## Catatan
Dokumentasi Baileys menegaskan `useMultiFileAuthState` hanya cocok untuk demo dan tidak ideal untuk production karena boros IO. Di paket ini fungsi tersebut tetap dipakai sebagai baseline kerja cepat agar sistem langsung bisa dijalankan, tetapi untuk production berat sebaiknya kamu ganti ke auth state storage custom berbasis database atau file store yang lebih efisien.
