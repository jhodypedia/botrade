const socket = typeof io !== 'undefined' ? io() : null;
if (socket) {
  const setText = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };
  const setQr = (dataUrl) => {
    const img = document.getElementById('wa-qr-image');
    const wrapper = document.getElementById('wa-qr-wrapper');
    if (!img || !wrapper) return;
    if (dataUrl) { img.src = dataUrl; img.style.display = 'block'; wrapper.style.display = 'inline-block'; }
    else { img.src = ''; img.style.display = 'none'; }
  };
  socket.on('dashboard:init', ({ metrics, whatsapp }) => {
    if (metrics) { setText('metric-active-users-live', metrics.activeUsers); setText('metric-active-subs-live', metrics.activeSubscriptions); setText('metric-analyses-live', metrics.totalAnalyses); setText('metric-wa-live', metrics.allowedWhatsapps); }
    if (whatsapp) { setText('wa-status-live', whatsapp.connection); setText('wa-pairing-live', whatsapp.pairingCode); setText('wa-error-live', whatsapp.error); setQr(whatsapp.qrDataUrl); }
  });
  socket.on('metrics:update', (metrics) => { setText('metric-active-users-live', metrics.activeUsers); setText('metric-active-subs-live', metrics.activeSubscriptions); setText('metric-analyses-live', metrics.totalAnalyses); setText('metric-wa-live', metrics.allowedWhatsapps); });
  socket.on('whatsapp:update', (whatsapp) => { setText('wa-status-live', whatsapp.connection); setText('wa-pairing-live', whatsapp.pairingCode); setText('wa-error-live', whatsapp.error); setQr(whatsapp.qrDataUrl); });
}
