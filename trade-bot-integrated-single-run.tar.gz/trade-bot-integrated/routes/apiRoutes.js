const express = require('express');
const { requireAdmin } = require('../middleware/auth');
const { getPool } = require('../db/connection');
const router = express.Router();
router.get('/health', (req, res) => res.json({ ok: true, app: process.env.APP_NAME || 'Trade Analyst Bot' }));
router.post('/admin/whitelist', requireAdmin, async (req, res) => {
  const pool = getPool();
  const { user_id, subscription_id, whatsapp_number, access_status } = req.body;
  await pool.query(`INSERT INTO whatsapp_access_list (user_id, subscription_id, whatsapp_number, access_status) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE access_status=VALUES(access_status), subscription_id=VALUES(subscription_id)`, [user_id, subscription_id || null, whatsapp_number, access_status || 'ALLOWED']);
  res.json({ ok: true });
});
module.exports = router;
