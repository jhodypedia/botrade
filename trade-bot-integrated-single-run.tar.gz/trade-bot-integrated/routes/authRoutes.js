const express = require('express');
const { registerUser, loginUser } = require('../services/authService');
const { createInitialSubscription } = require('../services/subscriptionService');
const router = express.Router();
router.get('/login', (req, res) => res.render('pages/auth/login', { title: 'Login' }));
router.get('/register', (req, res) => res.render('pages/auth/register', { title: 'Register' }));
router.post('/register', async (req, res) => {
  try {
    const userId = await registerUser(req.body);
    const invoice = await createInitialSubscription(userId, req.body.whatsapp_number);
    req.session.flash = { type: 'success', message: `Akun berhasil dibuat. Invoice ${invoice.invoiceCode} dibuat dengan total Rp${Number(invoice.totalAmount).toLocaleString('id-ID')}.` };
    res.redirect('/auth/login');
  } catch (error) {
    req.session.flash = { type: 'error', message: error.message || 'Registrasi gagal.' };
    res.redirect('/auth/register');
  }
});
router.post('/login', async (req, res) => {
  const user = await loginUser(req.body.email, req.body.password);
  if (!user) {
    req.session.flash = { type: 'error', message: 'Email atau password salah.' };
    return res.redirect('/auth/login');
  }
  req.session.user = { id: user.id, full_name: user.full_name, email: user.email, role: user.role };
  return ['SUPER_ADMIN', 'ADMIN'].includes(user.role) ? res.redirect('/admin') : res.redirect('/member');
});
router.post('/logout', (req, res) => req.session.destroy(() => res.redirect('/')));
module.exports = router;
