const express = require('express');
const { getPool } = require('../db/connection');
const router = express.Router();
router.get('/', async (req, res) => {
  const pool = getPool();
  const [[headline]] = await pool.query(`SELECT setting_value FROM system_settings WHERE setting_key='landing_headline' LIMIT 1`);
  const [[subheadline]] = await pool.query(`SELECT setting_value FROM system_settings WHERE setting_key='landing_subheadline' LIMIT 1`);
  const [bots] = await pool.query(`SELECT * FROM bot_profiles WHERE is_active=1`);
  const [plans] = await pool.query(`SELECT * FROM subscription_plans WHERE is_active=1`);
  res.render('pages/landing/index', { title: 'Landing Page', headline: headline?.setting_value, subheadline: subheadline?.setting_value, bots, plans });
});
router.get('/pricing', async (req, res) => {
  const pool = getPool();
  const [plans] = await pool.query(`SELECT * FROM subscription_plans WHERE is_active=1`);
  res.render('pages/landing/pricing', { title: 'Pricing', plans });
});
module.exports = router;
