function exposeLocals(req, res, next) {
  res.locals.appName = process.env.APP_NAME || 'Trade Analyst Bot';
  res.locals.currentPath = req.path;
  res.locals.year = new Date().getFullYear();
  res.locals.authUser = req.session.user || null;
  res.locals.flash = req.session.flash || null;
  delete req.session.flash;
  next();
}
module.exports = { exposeLocals };
