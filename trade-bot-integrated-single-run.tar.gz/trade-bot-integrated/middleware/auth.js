function requireAuth(req, res, next) {
  if (!req.session.user) {
    req.session.flash = { type: 'error', message: 'Silakan login dulu.' };
    return res.redirect('/auth/login');
  }
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.user || !['SUPER_ADMIN', 'ADMIN'].includes(req.session.user.role)) {
    req.session.flash = { type: 'error', message: 'Akses admin ditolak.' };
    return res.redirect('/auth/login');
  }
  next();
}
module.exports = { requireAuth, requireAdmin };
