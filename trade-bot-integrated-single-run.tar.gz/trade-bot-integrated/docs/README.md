# Trade Bot Integrated

## Run sekali
1. Copy `.env.example` ke `.env`
2. Isi MySQL dan Qwen credentials
3. `npm install`
4. Jalankan `npm start`

Perintah `npm start` akan menjalankan web server dan bot WhatsApp sekaligus dari `start-all.js`.

## Perintah terpisah
- `npm run start:web`
- `npm run start:bot`
- `npm run db:init`

## Seed admin
- Email: admin@tradebot.local
- Password: admin12345

## Catatan
- Web app dan bot share satu database MySQL.
- Bot cek `whatsapp_access_list` sebelum memproses analisa.
- Admin dashboard baca `bot_sessions` dan `analysis_logs` realtime.
