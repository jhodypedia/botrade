const { v4: uuidv4 } = require('uuid');
const { getPool } = require('../db/connection');
function randomUniqueCode() { return Math.floor(100 + Math.random() * 900); }
async function createInitialSubscription(userId, whatsappNumber) {
  const pool = getPool();
  const [[plan]] = await pool.query(`SELECT * FROM subscription_plans WHERE plan_code='ALL_BOT_MONTHLY' LIMIT 1`);
  const [subResult] = await pool.query(`INSERT INTO subscriptions (user_id, plan_id, status, current_whatsapp_number, notes) VALUES (?, ?, 'PENDING', ?, 'Menunggu pembayaran pertama')`, [userId, plan.id, whatsappNumber]);
  const uniqueCode = randomUniqueCode();
  const totalAmount = Number(plan.price_monthly) + uniqueCode;
  const invoiceCode = `INV-${uuidv4().slice(0, 8).toUpperCase()}`;
  const expiresAt = new Date(Date.now() + 15 * 60 * 1000);
  await pool.query(`INSERT INTO payment_invoices (invoice_code, user_id, subscription_id, base_amount, unique_code, total_amount, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?)`, [invoiceCode, userId, subResult.insertId, plan.price_monthly, uniqueCode, totalAmount, expiresAt]);
  await pool.query(`INSERT IGNORE INTO whatsapp_access_list (user_id, subscription_id, whatsapp_number, access_status) VALUES (?, ?, ?, 'PENDING')`, [userId, subResult.insertId, whatsappNumber]);
  return { invoiceCode, totalAmount, expiresAt };
}
async function activateSubscription(invoiceCode) {
  const pool = getPool();
  const [rows] = await pool.query(`SELECT * FROM payment_invoices WHERE invoice_code=? LIMIT 1`, [invoiceCode]);
  const invoice = rows[0];
  if (!invoice) throw new Error('Invoice tidak ditemukan');
  await pool.query(`UPDATE payment_invoices SET payment_status='PAID', paid_at=NOW() WHERE id=?`, [invoice.id]);
  await pool.query(`UPDATE subscriptions SET status='ACTIVE', start_at=NOW(), end_at=DATE_ADD(NOW(), INTERVAL 30 DAY) WHERE id=?`, [invoice.subscription_id]);
  await pool.query(`UPDATE whatsapp_access_list SET access_status='ALLOWED', activated_at=NOW(), expired_at=DATE_ADD(NOW(), INTERVAL 30 DAY) WHERE subscription_id=?`, [invoice.subscription_id]);
}
async function getMemberOverview(userId) {
  const pool = getPool();
  const [invoices] = await pool.query(`SELECT pi.invoice_code, pi.total_amount, pi.payment_status, pi.expires_at, s.status AS subscription_status, s.start_at, s.end_at FROM payment_invoices pi LEFT JOIN subscriptions s ON s.id = pi.subscription_id WHERE pi.user_id=? ORDER BY pi.id DESC LIMIT 20`, [userId]);
  const [whatsapps] = await pool.query(`SELECT whatsapp_number, access_status, activated_at, expired_at FROM whatsapp_access_list WHERE user_id=? ORDER BY id DESC`, [userId]);
  const [logs] = await pool.query(`SELECT asset_type, trigger_command, status, setup_score, created_at FROM analysis_logs WHERE user_id=? ORDER BY id DESC LIMIT 20`, [userId]);
  return { invoices, whatsapps, logs };
}
module.exports = { createInitialSubscription, activateSubscription, getMemberOverview };
