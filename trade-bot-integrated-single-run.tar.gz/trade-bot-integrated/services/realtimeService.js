const { getPool } = require('../db/connection');
function initRealtime(io) {
  io.on('connection', async (socket) => {
    socket.emit('dashboard:init', await buildState());
  });
}
async function buildState() {
  const pool = getPool();
  const [[users]] = await pool.query(`SELECT COUNT(*) AS total FROM users WHERE role='MEMBER'`);
  const [[subs]] = await pool.query(`SELECT COUNT(*) AS total FROM subscriptions WHERE status='ACTIVE'`);
  const [[analyses]] = await pool.query(`SELECT COUNT(*) AS total FROM analysis_logs`);
  const [[allowed]] = await pool.query(`SELECT COUNT(*) AS total FROM whatsapp_access_list WHERE access_status='ALLOWED'`);
  const [[session]] = await pool.query(`SELECT connection_status, pairing_code, last_error FROM bot_sessions ORDER BY id DESC LIMIT 1`);
  return { metrics: { activeUsers: users.total, activeSubscriptions: subs.total, totalAnalyses: analyses.total, allowedWhatsapps: allowed.total }, whatsapp: { connection: session?.connection_status || 'IDLE', pairingCode: session?.pairing_code || '-', error: session?.last_error || 'No error' } };
}
function heartbeat(io) {
  setInterval(async () => {
    try {
      const state = await buildState();
      io.emit('metrics:update', state.metrics);
      io.emit('whatsapp:update', state.whatsapp);
    } catch (error) {}
  }, 8000);
}
module.exports = { initRealtime, heartbeat };
