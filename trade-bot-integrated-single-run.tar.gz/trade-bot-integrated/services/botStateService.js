const { getPool } = require('../db/connection');
async function updateSession(fields = {}) {
  const pool = getPool();
  const allowed = ['connection_status', 'pairing_code', 'qr_text', 'last_error'];
  const keys = Object.keys(fields).filter(k => allowed.includes(k));
  if (!keys.length) return;
  const setSql = keys.map(k => `${k}=?`).join(', ');
  const values = keys.map(k => fields[k]);
  await pool.query(`UPDATE bot_sessions SET ${setSql} WHERE id=1`, values);
}
async function isAllowedWhatsapp(number) {
  const pool = getPool();
  const [rows] = await pool.query(`SELECT * FROM whatsapp_access_list WHERE whatsapp_number=? AND access_status='ALLOWED' LIMIT 1`, [number]);
  return rows[0] || null;
}
async function logAnalysis(payload) {
  const pool = getPool();
  await pool.query(`INSERT INTO analysis_logs (user_id, whatsapp_number, asset_type, trigger_command, model_name, decision_text, raw_reply, setup_score, processing_ms, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [payload.user_id || null, payload.whatsapp_number || null, payload.asset_type, payload.trigger_command, payload.model_name, payload.decision_text || null, payload.raw_reply || null, payload.setup_score || null, payload.processing_ms || null, payload.status || 'SUCCESS']);
}
async function findUserByWhatsapp(number) {
  const pool = getPool();
  const [rows] = await pool.query(`SELECT id, full_name, whatsapp_number FROM users WHERE whatsapp_number=? LIMIT 1`, [number]);
  return rows[0] || null;
}
module.exports = { updateSession, isAllowedWhatsapp, logAnalysis, findUserByWhatsapp };
