const { getPool } = require('../db/connection');
const { hashPassword, verifyPassword } = require('../utils/password');
async function registerUser(payload) {
  const pool = getPool();
  const passwordHash = await hashPassword(payload.password);
  const [result] = await pool.query(`INSERT INTO users (full_name, email, phone, whatsapp_number, password_hash, role, status) VALUES (?, ?, ?, ?, ?, 'MEMBER', 'ACTIVE')`, [payload.full_name, payload.email, payload.phone, payload.whatsapp_number, passwordHash]);
  return result.insertId;
}
async function loginUser(email, password) {
  const pool = getPool();
  const [rows] = await pool.query(`SELECT * FROM users WHERE email=? LIMIT 1`, [email]);
  const user = rows[0];
  if (!user) return null;
  const ok = await verifyPassword(password, user.password_hash);
  if (!ok) return null;
  return user;
}
module.exports = { registerUser, loginUser };
