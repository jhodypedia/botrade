const { getPool } = require('../db/connection');
async function getAdminOverview() {
  const pool = getPool();
  const [[users]] = await pool.query(`SELECT COUNT(*) AS total FROM users WHERE role='MEMBER'`);
  const [[subs]] = await pool.query(`SELECT COUNT(*) AS total FROM subscriptions WHERE status='ACTIVE'`);
  const [[analyses]] = await pool.query(`SELECT COUNT(*) AS total FROM analysis_logs`);
  const [[allowed]] = await pool.query(`SELECT COUNT(*) AS total FROM whatsapp_access_list WHERE access_status='ALLOWED'`);
  const [[session]] = await pool.query(`SELECT * FROM bot_sessions ORDER BY id DESC LIMIT 1`);
  const [recentInvoices] = await pool.query(`SELECT pi.invoice_code, pi.total_amount, pi.payment_status, pi.expires_at, u.full_name, u.whatsapp_number FROM payment_invoices pi JOIN users u ON u.id = pi.user_id ORDER BY pi.id DESC LIMIT 10`);
  const [members] = await pool.query(`SELECT id, full_name, email, whatsapp_number, status, role, created_at FROM users ORDER BY id DESC LIMIT 25`);
  const [logs] = await pool.query(`SELECT whatsapp_number, asset_type, trigger_command, status, setup_score, created_at FROM analysis_logs ORDER BY id DESC LIMIT 20`);
  return { stats: { activeUsers: users.total, activeSubscriptions: subs.total, totalAnalyses: analyses.total, allowedWhatsapps: allowed.total }, session, recentInvoices, members, logs };
}
async function updateBotSettings(payload) {
  const pool = getPool();
  await pool.query(`UPDATE system_settings SET setting_value=? WHERE setting_key='landing_headline'`, [payload.landing_headline]);
  await pool.query(`UPDATE system_settings SET setting_value=? WHERE setting_key='landing_subheadline'`, [payload.landing_subheadline]);
}
module.exports = { getAdminOverview, updateBotSettings };
